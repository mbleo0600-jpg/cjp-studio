# CJP Content Studio — Deployment Guide

## Your Login Details
- Email: Cockroachjantapartyorg@gmail.com
- Password: CJP@2026

## Deploy on Railway (Free to start)

### Step 1 — Create GitHub Account
Go to github.com and sign up (free)

### Step 2 — Upload code to GitHub
1. Go to github.com/new
2. Create repo named "cjp-studio"
3. Upload all files from this folder

### Step 3 — Deploy on Railway
1. Go to railway.app
2. Sign up with GitHub
3. Click "New Project" → "Deploy from GitHub"
4. Select your "cjp-studio" repo
5. Add these Environment Variables:
   - ANTHROPIC_KEY = (your key)
   - PASSWORD = CJP@2026
   - JWT_SECRET = cjp-swarm-secret-2026

### Step 4 — Get your URL
Railway gives you a URL like: cjp-studio.up.railway.app
That's your private dashboard link!

## What the Studio Does
- 📡 News Tab: Scans latest CJP news, generates AI images for each story
- 🎨 Post Studio: Generates complete Instagram posts with Hindi + English captions
- 🖼️ Image Generation: Creates dark political posters (free, no extra cost)
- 📋 One-tap copy: Copy caption + hashtags ready to paste on Instagram
